import './Daxhboard.css'

const Dashboard=()=>{
    return(
        <>
            <div className='navbar'>
                <div className='name'>
                    <p>daatgc</p>
                </div>
                <ul>
                    <li><a href="/profile">profile</a></li>
                    <li><a href="/">Singout</a></li>
                </ul>
                
            </div>
        </>
    )
}

export default Dashboard